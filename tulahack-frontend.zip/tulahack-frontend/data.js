export const ChatItemData = [
  {
    name: "Йога",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "event",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 янв 10:30",
    subscribers: 53,
    max_subscribers: 100,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Программирование на открытом воздухе",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "hobby",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 окт 10:30",
    subscribers: 53,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Футбол  на открытом воздухе",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "event",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 ноя 10:30",
    subscribers: 53,
    max_subscribers: 50,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Йога",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "hobby",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 мая 10:30",
    subscribers: 53,

    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Йога",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "event",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 янв 10:30",
    subscribers: 53,
    max_subscribers: 100,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Программирование на открытом воздухе",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "hobby",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 окт 10:30",
    subscribers: 53,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Футбол  на открытом воздухе",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "event",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 ноя 10:30",
    subscribers: 53,
    max_subscribers: 50,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Йога",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "hobby",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 мая 10:30",
    subscribers: 53,

    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Йога",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "event",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 янв 10:30",
    subscribers: 53,
    max_subscribers: 100,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Программирование на открытом воздухе",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "hobby",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 окт 10:30",
    subscribers: 53,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Футбол  на открытом воздухе",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "event",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 ноя 10:30",
    subscribers: 53,
    max_subscribers: 50,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Йога",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "hobby",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 мая 10:30",
    subscribers: 53,

    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Йога",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "event",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 янв 10:30",
    subscribers: 53,
    max_subscribers: 100,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Программирование на открытом воздухе",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "hobby",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 окт 10:30",
    subscribers: 53,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Футбол  на открытом воздухе",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "event",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 ноя 10:30",
    subscribers: 53,
    max_subscribers: 50,
    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
  {
    name: "Йога",
    description: "Идем заниматься йогой с друзьями и пивом",
    type: "hobby",
    image:
      "https://static.tildacdn.com/tild3366-6230-4162-b636-353136366132/99367B6E-B05B-467A-9.JPG",
    time: "23 мая 10:30",
    subscribers: 53,

    tags: [
      { name: "Спорт", link: "category/sport" },
      { name: "Природа", link: "category/nature" },
    ],
  },
];
