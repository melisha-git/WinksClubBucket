import ReduxProvider from "@/redux/provider";
import "./globals.css";
import { Inter } from "next/font/google";

export const metadata = {
  title: "MeetMe",
  description: "Связываем миры, создавая встречи",
};

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
});

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={inter.className}>
      <body>
        <ReduxProvider>{children}</ReduxProvider>
      </body>
    </html>
  );
}
